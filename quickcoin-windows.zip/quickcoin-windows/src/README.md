Quickcoin - Credit Cards Are Obsolete

	+ 5 second block target
	+ 4 confirmations
	+ Difficulty retarget is 1/4 day
	+ Max difficulty adjustment 125%
	+ 500 Million Coins  - Now thats an economy
	+ 8 coins per block for the life of the coin
	+ Fastest coin possible - believe me, we tested, any number lower results in unpredictable behavior..
	+ Pre-mine of 500,800 Coins (101 blocks) 0.1% (For bounties, future developemnt, etc)
	+ We want this coin to succeed - we pay bounties for dev work
	+ We pay bounties for Apple/Android Developers to use quickcoin for in app purchases
	+ We pay bounties/subsidy to accept Quickcoin in your online business
	+ We pay rewards for all infrasctucture improvements, including games, block explorers, stable pools, forums, etc
	+ Ports 9902(connect) and 9903(json rpc)



Development process
===================

Developers work in their own trees, then submit pull requests when
they think their feature or bug fix is ready.

The patch will be accepted if there is broad consensus that it is a
good thing.  Developers should expect to rework and resubmit patches
if they don't match the project's coding conventions (see coding.txt)
or are controversial.

The master branch is regularly built and tested, but is not guaranteed
to be completely stable. Tags are regularly created to indicate new
official, stable release versions of Litecoin.

Feature branches are created when there are major new features being
worked on by several people.

From time to time a pull request will become outdated. If this occurs, and
the pull is no longer automatically mergeable; a comment on the pull will
be used to issue a warning of closure. The pull will be closed 15 days
after the warning if action is not taken by the author. Pull requests closed
in this manner will have their corresponding issue labeled 'stagnant'.

Issues with no commits will be given a similar warning, and closed after
15 days from their last activity. Issues closed in this manner will be 
labeled 'stale'. 
